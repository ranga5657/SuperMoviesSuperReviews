//package org.role.based.auth.jwt.service;
//
//
//import java.util.List;
//
//import org.assertj.core.api.Assertions;
//import org.junit.jupiter.api.MethodOrderer;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.TestMethodOrder;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.jupiter.MockitoExtension;
////import org.role.based.auth.jwt.entity.AdminData;
//import org.role.based.auth.jwt.entity.Comment;
//import org.role.based.auth.jwt.repo.CommentRepository;
//import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//////@RunWith(SpringRunner.class)
////@SpringBootTest
////@ExtendWith(MockitoExtension.class)
//////@DataJpaTest 
//////@RunWith(SpringRunner.class) 
//
//
//@SpringBootTest
//@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
//
//public class CommentServiceTests {
//	
//	
//	
////	@InjectMocks
//	
//	
//	@InjectMocks
//	private CommentService Service;
//	
//	
//	//@Autowired
//	@Mock
//	private CommentRepository Repository;
//    
////     private Comment comment;
////     private Comment comment1;
//	
////     
//	
////
////	//@Before(value = "")
////	public void init() {
////		MockitoAnnotations.openMocks(this);
////	}
//     
//     
//     
// 	@Test
// 	public void getAllCommentsTest()
// 	{
////
// 		List<Comment> emplist=Service.listAll();
// 		System.out.println(emplist);
// 		
// 		Assertions.assertThat(emplist.size()).isGreaterThan(0);
// 	}
// 	
// 	
// 	
// 	
// 	
// 	
// 	
// 	
// 	
//}
